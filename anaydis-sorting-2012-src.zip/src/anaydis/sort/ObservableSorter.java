package anaydis.sort;

import org.jetbrains.annotations.NotNull;

/**
 * Análisis y Diseño de Algoritmos - Práctica 2012
 *
 * Interface to provide holding support for {@link SorterListener listeners}
 */
public interface ObservableSorter 
{
    /**
     * Adds the given SorterListener
     * @param listener to be added
     */
    void addSorterListener(@NotNull final SorterListener listener);

    /**
     * Removes the given SorterListener
     * @param listener to be removed
     */
    void removeSorterListener(@NotNull final SorterListener listener);
}
