package anaydis.sort;

/**
 * Análisis y Diseño de Algoritmos - Práctica 2012
 *
 * This enumeration represents a {@link Sorter sorter} type.
 *
 * Each sorter must return a not null valid type {@link Sorter#getType()}
 */
public enum SorterType
{
    INSERTION,
    SELECTION,
    BUBBLE,
    MERGE,
    MERGE_BOTTOM_UP,
    QUICK,
    QUICK_CUT,
    QUICK_NON_RECURSIVE,
    QUICK_MED_OF_THREE,
    QUICK_THREE_PARTITION,
    SHELL,
    H,
    HEAP,
    HEAP_TERNARY
}
