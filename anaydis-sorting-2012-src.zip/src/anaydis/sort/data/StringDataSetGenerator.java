package anaydis.sort.data;

import org.jetbrains.annotations.NotNull;

import java.util.*;

/**
 * Análisis y Diseño de Algoritmos - Práctica 2012
 *
 * String-typed implementation of {@link DataSetGenerator}
 *
 * This implementation internally uses a dictionary! Other implementations
 * (e.g. IntegerDataSetGenerator) should dynamically generate each List<T>
 */
public class StringDataSetGenerator
    implements DataSetGenerator<String>
{
    private final List<String> dictionary;

    public StringDataSetGenerator() {
        dictionary = initDictionary();
    }

    @NotNull public List<String> createAscending(final int length)
    {
        if(length > dictionary.size()) {
            throw new IllegalArgumentException("This DataSetGenerator is limited to " + dictionary.size() + " values");
        }

        final List<String> copy = new ArrayList<String>();

        copy.addAll(dictionary.subList(0, length));

        return copy;
    }

    @NotNull public List<String> createDescending(int length)
    {
        final List<String> copy = createAscending(length);

        /* Hey!! {@link Collections#reverse(List)} SHOULD NOT BE USED ON THE INTEGER IMPLEMENTATION! Why not?! */
        Collections.reverse(copy);

        return copy;
    }

    @NotNull public List<String> createRandom(int length)
    {
        final List<String> copy = createAscending(length);

        /* Hey!! {@link Collections#shuffle(List)} SHOUL NOT BE USED ON THE INTEGER IMPLEMENTATION! Why not?! */
        Collections.shuffle(copy);

        return copy;
    }

    @NotNull public Comparator<String> getComparator() {
        return STRING_COMPARATOR;
    }

    private List<String> initDictionary()
    {
        return  Arrays.asList("ALICE", "AMANDA",
                "AMY", "ANDREA", "ANGELA", "ANN", "ANNA", "ANNE", "ANNIE",
                "ASHLEY", "BARBARA", "BETTY", "BEVERLY", "BONNIE", "BRENDA",
                "CARMEN", "CAROL", "CAROLYN", "CATHERINE", "CHERYL",
                "CHRISTINA", "CHRISTINE", "CINDY", "CLARIRRI", "CONNIE", "CRYSTAL",
                "CYNTHIA", "DAWN", "DEBORAH", "DEBRA", "DENISE", "DIANA",
                "DIANE", "DONNA", "DORIS", "DOROTHY", "EDITH", "EDNA",
                "ELIZABETH", "EMILY", "EVELYN", "FLORENCE", "FRANCES",
                "GLADYS", "GLORIA", "GRACE", "HEATHER", "HELEN", "IRENE",
                "JACQUELINE", "JANE", "JANET", "JANICE", "JEAN", "JENNIFER",
                "JESSICA", "JOAN", "JOYCE", "JUDITH", "JUDY", "JULIA", "JULIE",
                "KAREN", "KATHERINE", "KATHLEEN", "KATHRYN", "KATHY", "KELLY",
                "KIM", "KIMBERLY", "LAURA", "LILLIAN", "LINDA", "LISA", "LOIS",
                "LORI", "LOUISE", "MARGARET", "MARIA", "MARIE", "MARILYN",
                "MARTHA", "MARY", "MELISSA", "MICHELLE", "MILDRED", "NANCY",
                "NICOLE", "NORMA", "PABLIUS", "PAMELA", "PATRICIA", "PAULA", "PEDRO",
                "PEGGY", "PHYLLIS", "RACHEL", "REBECCA", "RITA", "ROBIN", "ROSA",
                "ROSE", "RUBY", "RUTH", "SANDRA", "SARA", "SARAH", "SHARON", "SHIRLEY",
                "STEPHANIE", "SUSAN", "TAMMY", "TERESA", "THERESA", "TIFFANY", 
                "TINA", "TRACY", "VICTORIA", "VIRGINIA", "WANDA", "WENDY");
    }

    /* Private static final field to return always the same instance of Comparator<String>
     upon {@link #getComparator()} invocation */
    private static final Comparator<String> STRING_COMPARATOR = new Comparator<String>(){

        public int compare(String a, String b)
        {
            return a.compareTo(b);
        }
    };
}
