package anaydis.sort;

/**
 * Análisis y Diseño de Algoritmos - Práctica 2012
 *
 * Interface to listen sorting procedure
 */
public interface SorterListener
{
    /**
     * Notifies greatness comparison between the 'i' and 'j' indexes
     *
     * @param i index to compare
     * @param j index to compare
     */
    void greater(final int i, final int j);

    /**
     * Notifies equals comparison between the 'i' and 'j' indexes
     *
     * @param i index to compare
     * @param j index to compare
     */
    void equals(final int i, final int j);

    /**
     * Notifies swap between the 'i' and 'j' indexes
     *
     * @param i index to swap
     * @param j index to swap
     */
    void swap(final int i, final int j);

    /**
     * Notifies scope of sort between the 'from' and 'to' indexes
     *
     * @param from index to determine scope start
     * @param to index to determine scope end
     */
    void box(final int from, final int to);


    /**
     * Notifies a copy from a source to a target array between the 'from' and 'to' indexes
     * Copy may be from-source-to-aux or from-aux-to-source, indicated by the 'copyToAux' boolean
     *
     * @param from index to copy from the value on the source array
     * @param to index to paste the value on the target array
     * @param copyToAux indicating if it's a 'from-source-to-aux' copy or the other way round
     */
    void copy(final int from, final int to, final boolean copyToAux);
}
