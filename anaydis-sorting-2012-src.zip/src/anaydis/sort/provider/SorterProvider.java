package anaydis.sort.provider;

import anaydis.sort.Sorter;
import anaydis.sort.SorterType;
import org.jetbrains.annotations.NotNull;

/**
 * Análisis y Diseño de Algoritmos - Práctica 2012
 * 
 * {@link SorterProvider provider} will instantiate each and every implemented {@link Sorter sorter}
 */
public interface SorterProvider
{
    /**
     * Given the SorterType, this method will return the corresponding {@link Sorter sorter}
     *
     * If given type is not yet implemented, an IllegalArgumentException must be thrown
     *
     * IMPLEMENTATION NOTE: Internally all sorters should be held with a map
     * (e.g.: Map<SorterType, Sorter> sorters = new EnumMap<SorterType, Sorter>)
     *
     * @param type Sorter's type
     * @return corresponding Sorter
     */
    @NotNull Sorter getSorterForType(@NotNull final SorterType type);

    /* Return all available Sorters */
    @NotNull Iterable<Sorter> getAllSorters();
}
