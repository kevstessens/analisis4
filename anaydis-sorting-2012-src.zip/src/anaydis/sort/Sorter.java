package anaydis.sort;

import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.List;

/**
 * Análisis y Diseño de Algoritmos - Práctica 2012
 *
 * Basic interface for a {@link Sorter sorters}. All concrete sorters must implement this interface.
 *
 * E.g.: BubbleSorter, InsertionSorter, SelectionSorter, MergeSorter, QuickSorter, ShellSorter, HSorter
 *
 * The AbstractSorter class should be abstract and implement this interface. All concrete sorters should extend from it.
 */
public interface Sorter
{
    /**
     * Sorts the specified list into ascending order, according to the natural ordering of its elements.
     * @param comparator to be used for sorting
     * @param list to be sorted.
     */
    <T> void sort(@NotNull final Comparator<T> comparator, @NotNull final List<T> list);

    /**
     * Returns the {@link SorterType type}
     * @return Sorter's type.
     */
    @NotNull SorterType getType();
}
